# image_registration

- [1. 简介](#1)
- [2. 相关参考](#2)
- [3. 使用文档](#3)
- [4. 后续计划](#4)


<a name="1"></a>

## 1. 简介
这是一个用于图像识别（目标检测）的基础库
相关介绍放置到[testerhome](https://testerhome.com/topics/33034) | [github](docs/introduction.md)


<a name="2"></a>

## 2. 相关参考
本库目前使用了两种基于opencv的匹配方法,对应的匹配算法如下

- 模板匹配
  - MatchTemplate
- 特征点匹配
  - SIFT
  - ORB
  - AKAZE
  - SURF


<a name="3"></a>

## 3. 使用文档

编辑中....


<a name="4"></a>

## 4. 后续计划
优化识别速度,增加相应的开发工具以及服务器的部署方式

有问题与建议欢迎留言或者提issue
