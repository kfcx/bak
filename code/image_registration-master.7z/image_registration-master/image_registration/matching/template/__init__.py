#! usr/bin/python
# -*- coding:utf-8 -*-
from .matchTemplate import MatchTemplate, CudaMatchTemplate
